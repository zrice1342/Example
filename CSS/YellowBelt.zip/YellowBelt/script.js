function hide(){
    document.getElementById("cookies").style.display = "none"
}


function over(element){
    c
    console.log("eatmyass")
}